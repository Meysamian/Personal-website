<script setup>
import { Link } from '@inertiajs/vue3';


</script>

<template>

    <div id="certifications" class="put-a-space-in-mobile">
        <!-- Just for a space between title and menu in mobile-->
    </div>
    <div id="certifications-main-box" class="sky-box">

        <div class="sky-title">
            Certifications
        </div>

        <div class=" p-6 text-justify text-white">

            <table class="w-full certifications">
                <tr class="tr-sky">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-400"> </td>
                    <td>
                        <div class="font-bold">Project Management Body of Knowledge, Equal Assurance, Australia (2017)</div>
                    </td>
                </tr>

                <tr class="tr-sky">
                    <td class=""> </td>
                    <td class="border-l-2 border-gray-400"> </td>
                    <td>
                        <div class="font-bold">
                            Project management (220 hours), University of Tehran
                            <div class="ml-6 font-normal leading-6">
                                {PMBOK, Prince2, PMO, Microsoft Project, Primavera, Problem Solving, Negotiation, Teamwork, Scrum, Excel, HSE, Contract, Claim} (2017)
                            </div>
                        </div>
                    </td>
                </tr>

                <tr class="tr-sky">
                    <td class="md:w-6"> </td>
                    <td class="border-l-2 border-gray-400"> </td>
                    <td>
                        <div class="font-bold">E-shop, Barnamenevis Institute (2013)</div>
                    </td>
                </tr>

                <tr class="tr-sky">
                    <td class="md:w-6"> </td>
                    <td class="border-l-2 border-gray-400"> </td>
                    <td>
                        <div class="font-bold">PHP & MYSQL, Web Design Methodology, and Web Design Foundation, Tehran Technical Institute (2012)</div>
                    </td>
                </tr>

                <tr class="tr-sky">
                    <td class="md:w-6"> </td>
                    <td class="border-l-2 border-gray-400"> </td>
                    <td>
                        <div class="font-bold">Microsoft Project, Rayab (2012)</div>
                    </td>
                </tr>

            </table>

        </div>

    </div>

</template>
