<script setup>
import { Link } from '@inertiajs/vue3';


</script>

<template>

    <div id="experiences" class="put-a-space-in-mobile">
        <!-- Just for a space between title and menu in mobile-->
    </div>
    <div id="experiences-main-box" class="white-box">

        <div class="white-title">
            Experiences
        </div>

        <div class="p-4 md:p-6 text-justify">

            <table class="w-full ">
                <tr class="tr-white">
                    <td class="w-2 md:w-6"> </td>
                    <td class="w-2 md:w-6 border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Freelance Web Developer</span> - Self-employed (2022 - now)
                        <div class="ml-10">
                            <ul class="list-image-[url(/picture/accept-li.png)]">
                                <li>
                                    Consulting, developing, and providing ongoing support for multiple web projects of small businesses.
                                </li>
                                <li>
                                    Analysing, planning, and developing a survey system that empowers users to create diverse types of surveys and analyse collected data and opinions from individuals
                                </li>
                                <li>
                                    Designed and developed this personal Website.
                                </li>
                            </ul>

                            <div class="text-gray-400">
                                (PHP, Laravel, MYSQL, Vue, Tailwind, JavaScript, jQuery, WordPress, Excel and Scrum)
                            </div>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>

                <tr class="tr-white">
                    <td> </td>
                    <td class="border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Web Developer & Project Planner </span> - <a href="https://enico.ir/">Enico</a> (2020 - 2022)
                        <div class="ml-10">
                            <ul class="list-image-[url(/picture/accept-li.png)]">
                                <li>
                                    Scheduled and developed Tabib, an automation system for the Ministry of Health and Medical Education. This included the creation of Logbook, Evaluation, Rotation, Postgraduate Education, and some other sub-systems to result in efficient solutions.
                                </li>
                            </ul>
                            <div class="text-gray-400">
                                (ASP.Net MVC, SQL Server, JavaScript, jQuery and Excel)
                            </div>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>

                <tr class="tr-white">
                    <td> </td>
                    <td class="border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Web Developer & Project Planner  </span> - <a href="https://www.linkedin.com/company/pars-tasmim/">Pars Tasmim</a> (2018 - 2020)
                        <div class="ml-10">
                            <div>
                                <div class="font-bold">1)	Knowledge Management System for use in MTN-Irancell</div>
                                <ul class="list-image-[url(/picture/accept-li.png)] ml-10">
                                    <li>Collaborated as a team member to create the software requirements specification, developed a detailed project plan, and prepared a comprehensive work breakdown structure to clarify the project development way.</li>
                                    <li>Successfully managed project scope, time and team for ensuring concentration on the right tasks.</li>
                                    <li>Led the design and development of the project in a collaborative environment.</li>
                                </ul>
                            </div>

                            <div>
                                <div class="font-bold">2)	Knowledge Base System for using the customer relationship department in MTN-Irancell</div>
                                <ul class="list-image-[url(/picture/accept-li.png)] ml-10">
                                    <li>Effectively planned project scope and monitored the timebox to meet all assigned tasks on each Sprint.</li>
                                    <li>Designed and developed the main structure of the project, including content, user and authorisation management, dashboard, reporting, notifications, and feedback mechanisms within an agile environment.</li>
                                    <li>Developed a feature to enable importing of Word and Excel documents as searchable knowledge within the project.</li>
                                    <li>Designed and implemented a feature enabling managers to define support processes as a flowchart, which can be executed by staff members in the customer relationship department.</li>
                                    <li>Created and implemented a professional exam system, resulting in a successful assessment tool.</li>
                                    <li>Achieved 100% satisfaction by successfully deploying the system to MTN-Irancell while meeting all project goals and objectives. </li>
                                </ul>
                            </div>
                            <div class="text-gray-400">
                                (JavaScript, jQuery, GoJS, Excel, Java, Oracle, Visio, SVN, Jira and Scrum)
                            </div>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>

                <tr class="tr-white">
                    <td> </td>
                    <td class="border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Web Developer & Project Management Officer </span> - <a href="https://samasoft.net/en">Sama Samaneh</a> (2015 - 2018)
                        <div class="ml-10">
                            <ul class="list-image-[url(/picture/accept-li.png)]">
                                <li>Planned and developed SamaSMS, a messaging system for over 150 universities in an agile environment.</li>
                                <li>Managed the SamaSMS support team, working collaboratively with team members to resolve reported issues.</li>
                                <li>Performed a cost-benefit and process analysis to identify areas for improvement and optimise development processes.</li>
                                <li>Led the planning, design and development of an internal portal based on optimal processes, including multiple sub-systems such as knowledge management and documentation system.</li>
                            </ul>
                            <div class="text-gray-400">
                                (PHP, Yii, MYSQL, JavaScript, jQuery, Excel, Redmine and Scrum)
                            </div>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>

                <tr class="tr-white">
                    <td> </td>
                    <td class="border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Planning Expert </span> - RayAb Consulting Engineers (2010 - 2015)
                        <div class="ml-10">
                            <ul class="list-image-[url(/picture/accept-li.png)]">
                                <li>Achieved eleven certifications for the company's consulting services from the Budget and Planning Organisation</li>
                                <li>Successfully planned, implemented, and managed supplementary insurance processes for a group of 1500 insured individuals.</li>
                                <li>Managed and optimised network and software systems to increase staff productivity and ease of use.</li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>

                <tr class="tr-white">
                    <td> </td>
                    <td class="border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Information Technology Manager </span> - Amirkabir University of Arak (2005 – 2008)
                        <div class="ml-10">
                            <ul class="list-image-[url(/picture/accept-li.png)]">
                                <li>Improved user experience and productivity by managing, maintaining, and updating software, computer systems, and site equipment.</li>
                                <li>Set up and maintained an educational automation system and provided training to university staff to improve the selection unit processes.</li>
                                <li>Prepared a road map for the university’s development program for the following year.</li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>

                <tr class="bg-[url('/picture/arrow-for-timeline.png')] bg-no-repeat bg-[left_top_0.35rem] bg-[length:60px_15px]">
                    <td> </td>
                    <td class="border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Others </span>
                        <div class="ml-10">
                            <ul class="list-image-[url(/picture/accept-li.png)]">
                                <li>Designed & developed more than thirty websites for various companies and businesses (2011 - 2022).
                                    <div class="text-gray-400">
                                        (PHP, Yii, MYSQL, JavaScript, jQuery, Excel, Redmine and Scrum)
                                    </div>
                                </li>
                                <li>Translated the book "Essential Kanban Condensed" into Persian language and distributed it to colleagues at Sama Samaneh (2017)</li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>

                <tr class="tr-white">
                    <td> </td>
                    <td class="border-l-2 border-gray-500"> </td>
                    <td>
                        <span class="font-bold">Voluntary Experiences</span>
                        <div class="ml-10">
                            <ul class="list-image-[url(/picture/accept-li.png)]">
                                <li>Participated in various groups to clean up the environment of the North Tehran mountains (2015 - 2022).</li>
                                <li>Designed, developed and supported a website for the Chura NGO, which focused on the restoration of the Hamoun wetland and improving the lives of local residents (2013 - 2016)..</li>
                                <li>Assisted in organising three conferences in Tehran about promoting healthy food (2010 - 2011).</li>
                                <li>Provided services to a newspaper office in Arak by introducing books and influential individuals and writing editorials (2006 - 2007). </li>
                            </ul>
                        </div>
                    </td>
                </tr>
                <tr class="">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-500"> </td>
                    <td>
                        <div class="separator-paragraph-1"></div>
                    </td>
                </tr>


            </table>


        </div>

    </div>

</template>
