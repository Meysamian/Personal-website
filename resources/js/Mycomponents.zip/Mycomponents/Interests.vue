<script setup>
import { Link } from '@inertiajs/vue3';


</script>

<template>

    <div id="interests" class="put-a-space-in-mobile">
        <!-- Just for a space between title and menu in mobile-->
    </div>
    <div id="interests-main-box" class="white-box">

        <div class="white-title">
            Interests
        </div>

        <div class=" p-6 text-justify">

            I have a strong passion for the environment and used to engage in mountain climbing. However, since coming to Britain, I've shifted more towards hiking. I find them to be both a means of challenging myself and an opportunity for solitude, allowing for reflection and concentration.
            <div class="flex justify-center p-6">
                <img class="w-full md:w-2/5 align-center" src="/picture/snow-02.jpeg" alt="">
            </div>
            <br>
            Over the past two decades, my interests have been primarily focused on Cinema, Philosophy, Psychology, and Literature. However, in recent years, I came to the realisation that a comprehensive understanding of the world requires a solid grasp of History.
            As a result, History has become an integral addition to my list of passions.
            <br><br>
            Considering the belief that art is essential for life, I am intrigued by the idea of starting to play the harmonica as a first step, with a desire to continue learning.
        </div>

    </div>

</template>
