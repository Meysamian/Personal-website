<script setup>
import { Link } from '@inertiajs/vue3';


</script>

<template>

    <div id="educations" class="put-a-space-in-mobile">
        <!-- Just for a space between title and menu in mobile-->
    </div>
    <div id="educations-main-box" class="sky-box">

        <div class="sky-title">
            Educations
        </div>

        <div class=" p-6 text-justify text-white">

            <table class="w-full ">
                <tr class="tr-sky">
                    <td class="w-2 md:w-6"> </td>
                    <td class="w-8 border-l-2 border-gray-400"> </td>
                    <td>
                        <span class="font-bold">BSc: Project Management Engineering, Payam Noor University (2012 - 2017)</span>
                    </td>
                </tr>


                <tr class="tr-sky">
                    <td class="w-8"> </td>
                    <td class="w-8 border-l-2 border-gray-400"> </td>
                    <td>
                        <span class="font-bold">As: Software, Amirkabir University of Arak (2000 - 2003)</span>
                    </td>
                </tr>

            </table>

        </div>

    </div>

</template>
