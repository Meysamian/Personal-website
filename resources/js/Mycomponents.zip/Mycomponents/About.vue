<script setup>
import { Link } from '@inertiajs/vue3';


</script>

<template>

    <div id="about" class="put-a-space-in-mobile">
        <!-- Just for a space between title and menu in mobile-->
    </div>
    <div id="about-main-box" class="white-box">

        <div class="white-title">
            About me
        </div>

        <div class=" p-6 text-justify">
            Greetings,
            <br><br>
            I am a seasoned web development specialist with a decade of experience in esteemed organizations. My expertise spans the entire spectrum of web project development, from meticulous analysis and scheduling to agile optimization.
            <br><br>

            In addition to my technical prowess, I am well-versed in project management methodologies such as PMBOK, Scrum, and Kanban, leveraging various tools to drive success.
            <br><br>

            Over the past ten years, I have pursued knowledge across both technical and non-technical domains, shaping my professional journey and guiding me towards continuous growth.
            <br><br>

            Beyond my professional pursuits, I am an avid explorer, driven by a quest for wisdom and a passion for understanding the intricacies of the world. I thrive on meaningful interactions, diverse experiences, and the opportunity to expand my horizons.

            <br><br>
            Welcome to my personal website, where you can learn more about my journey and aspirations.
            <br><br>

            Best regards,
            <br>

            Meysam
        </div>

    </div>

</template>
