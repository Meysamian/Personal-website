<script setup>
import { Link } from '@inertiajs/vue3';

</script>

<template>

    <div id="skills" class="put-a-space-in-mobile">
        <!-- Just for a space between title and menu in mobile-->
    </div>
    <div id="skills-main-box" class="white-box">

        <div class="white-title">
            Skills
        </div>

        <div class=" p-6 md:pl-16 text-justify">

            <div class="font-bold">Web development:</div>
            <div class="ml-10">
                <ul class="list-image-[url(/picture/accept-li.png)]">
                    <li>
                        PHP (Yii and Laravel), ASP.NET MVC, MySQL and SQL Server
                    </li>
                    <li>
                        HTML, CSS, Bootstrap, JavaScript, Vue, jQuery, Sass, Tailwind and TypeScript
                    </li>
                    <li>
                        PhpStorm and Visual Studio
                    </li>
                    <li>
                        WordPress
                    </li>
                </ul>
            </div>

            <div class="font-bold mt-6">Project management:</div>
            <div class="ml-10">
                <ul class="list-image-[url(/picture/accept-li.png)]">
                    <li>
                        PMBOK, Scrum, Kanban and PMO services
                    </li>
                    <li>
                        Microsoft Project, Jira, Redmine and Trello
                    </li>
                </ul>
            </div>

            <div class="font-bold mt-6">General:</div>
            <div class="ml-10">
                <ul class="list-image-[url(/picture/accept-li.png)]">
                    <li>
                        Microsoft Office (Excel, Word, PowerPoint, Visio) and Photoshop
                    </li>
                </ul>
            </div>

        </div>

    </div>

</template>
