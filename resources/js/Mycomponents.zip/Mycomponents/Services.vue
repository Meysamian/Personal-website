<script setup>
import { Link } from '@inertiajs/vue3';


</script>

<template>

    <div id="services" class="put-a-space-in-mobile">
        <!-- Just for a space between title and menu in mobile-->
    </div>
    <div id="services-main-box" class="sky-box">

        <div class="sky-title">
            Services
        </div>

        <div class=" p-6">

            <div class="flex flex-wrap text-white border-b pb-6 rounded-b-xl">
                <div class="w-full text-center mb-8">
                    <div class="title-services">
                        Web Development
                    </div>
                </div>
                <div class="w-full text-justify mb-4">
                    Web development is an art. An art that evolves with experience and knowledge, and this journey is endless. Web development requires a deep understanding of all related components, server-side programming, client-side design and programming, proper database design, and most importantly, the integration of these components alongside all necessary configurations, so that the final system can function optimally.
                </div>
                <div class="w-full md:w-5/12 m t-6 my-auto">
                    <img class="rounded-lg max-w-[75%] mx-auto" src="\picture\web-development.png" alt="">
                </div>
                <div class="w-full md:w-7/12 text-justify mt-6 md:mt-2">
                    <br>
                    In today's world, most users access websites through mobile devices, so implementing pages with consideration for different outputs is crucial.
                    <br><br>
                    With about eleven years of experience in web development, ranging from small websites to large systems, I am delighted to apply my experience, knowledge, and expertise in web development projects.
                </div>
            </div>


            <div class="flex flex-wrap text-white border-b border-t pb-6 pt-10 rounded-xl m t-6">
                <div class="w-full text-center mb-8">
                    <div class="title-services">
                        Project Scheduling
                    </div>
                </div>
                <div class="w-full text-justify mb-4">
                    Scheduling is crucial for any serious and vital project, as without a proper schedule, either the project will not be completed, or if it does, it will incur significant time and cost overruns. With a scheduling plan in place, the sequence of tasks, necessary resources, required equipment, time needed for each phase, and ultimately the predicted cost can be anticipated.
                </div>

                <div class="w-full md:w-7/12 mt-6 md:mt-2 text-justify">
                    When a scheduling plan follows its correct path, we can achieve the most optimal time and cost outcomes.
                    <br><br>
                    As someone who has studied Project Management Engineering at university, participated in numerous project management courses, and is familiar with reputable concepts, frameworks, and standards, as well as actively collaborated on numerous projects in preparing scheduling documents, I would be delighted to apply this expertise, knowledge, and experience to upcoming projects.
                </div>
                <div class="w-full md:w-5/12 my-auto">
                    <img class="rounded-lg max-w-[75%] mx-auto" src="\picture\scheduling.png" alt="">
                </div>
            </div>


            <div class="flex flex-wrap text-white border-b border-t pb-6 pt-10 rounded-xl m t-6">
                <div class="w-full text-center mb-8">
                    <div class="title-services">
                        Development Process Optimisation
                    </div>
                </div>
                <div class="w-full text-justify mb-4">
                    Good results come from proper processes. A process is a system that has specific inputs, a path, and defined outputs.
                </div>

                <div class="w-full md:w-7/12 mt-6 md:mt-2 text-justify">
                    In essence, a process takes certain inputs, traverses a path based on those inputs and other necessary factors, and ultimately yields specific outputs. Optimizing the process leads to optimization of time and cost, which ultimately increases productivity in the overall set. This means achieving the same outputs or higher quality outputs with less work, time, cost, and fewer resources expended.
                </div>
                <div class="w-full md:w-5/12 my-auto">
                    <img class="rounded-lg max-w-[75%] mx-auto" src="\picture\process-optimisation.png" alt="">
                </div>
            </div>


        </div>

    </div>

</template>
